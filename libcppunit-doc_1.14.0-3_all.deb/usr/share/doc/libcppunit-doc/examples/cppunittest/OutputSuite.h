#ifndef CPPUNITTEST_OUTPUTSUITE_H
#define CPPUNITTEST_OUTPUTSUITE_H

#include <cppunit/Portability.h>
#include <string>

inline std::string outputSuiteName()
{
  return "Output";
}


#endif // CPPUNITTEST_OUTPUTSUITE_H
